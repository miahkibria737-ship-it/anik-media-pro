ANIK MEDIA & EDITING — PROFESSIONAL WEBSITE STARTER
=================================================

Included:
- Responsive custom HTML/CSS/JavaScript website
- Services with editable example starting prices
- Portfolio gallery with category filters
- WhatsApp order form (opens a prefilled WhatsApp message)
- Portfolio CMS setup files for Decap CMS + Netlify Identity/Git Gateway
- Netlify config

IMPORTANT BEFORE PUBLISHING
---------------------------
1. Replace the example portfolio images with your own work. The existing gallery items are placeholders/examples.
2. Prices shown are sample starting prices. Update them to your real prices before launch.
3. The hero graphic is a typographic placeholder, not your portrait. To show your own photo, add it to assets/ (for example assets/anik.jpg) and edit index.html.
4. Update /admin/config.yml:
   - Replace YOUR-SITE-NAME.netlify.app with your actual Netlify URL.
   - Change branch: main if your GitHub default branch has a different name.
5. This package does not deploy itself. You must upload it to a GitHub repository and deploy that repository with Netlify.

PUBLISH WITH NETLIFY + GITHUB
-----------------------------
A. Create/sign in to GitHub and create a new repository, e.g. anik-media-website.
B. Upload all files/folders in this ZIP to the repository root (index.html must be at root).
C. In Netlify, choose Add new site -> Import an existing project -> GitHub, select your repository, and deploy.
D. In Netlify Site configuration, enable Identity (if available for your site/account), set registration to Invite only, then invite your own email.
E. Enable Git Gateway under Identity/Services.
F. Edit admin/config.yml and replace YOUR-SITE-NAME.netlify.app with the deployed URL, commit/push the change, and wait for redeploy.
G. Visit https://YOUR-SITE-NAME.netlify.app/admin/ and log in using the invited account. Add/edit portfolio items there.
H. For safer admin access, use Invite only and do not share your admin login. CMS publishes changes into your connected Git repository.

If Netlify Identity/Git Gateway is unavailable in your account:
- The site and WhatsApp order form still work.
- Use GitHub to edit content/portfolio.json and add images to uploads/, or choose another CMS that supports your host.

OWN DOMAIN
----------
1. Buy a domain from a trusted registrar. Check availability first; domain names and prices vary.
2. In Netlify: Domain management -> Add a domain you own.
3. Follow Netlify's exact DNS instructions at your registrar. Do not copy random DNS records from tutorials.
4. Wait for DNS and HTTPS provisioning to complete. Keep the Netlify subdomain working as a fallback.
5. Update site_url and display_url in admin/config.yml to your final domain and redeploy.

WHATSAPP
--------
Configured number: +8801603897874 (international format from 01603897874).
Form creates a WhatsApp message; customer must press Send in WhatsApp. No message is sent automatically.

EMAIL / FACEBOOK
----------------
Email: miahkibria737@gmail.com
Facebook: https://www.facebook.com/share/1EYJjXAfwm/

SECURITY / LIMITATIONS
----------------------
- This is a static website; the order form does not store customer details in a database.
- Do not collect sensitive personal data through the form.
- The CMS is for portfolio content; keep admin access invite-only.
- Test all links, images, spelling, price information, and mobile layout before promoting the site.
