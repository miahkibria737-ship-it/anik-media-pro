const WHATSAPP_NUMBER = "8801603897874";
const FALLBACK_PORTFOLIO = [
  {title:"Social Media Poster",category:"poster",image:"https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=900&q=80",description:"Promotional design sample"},
  {title:"Creative Branding",category:"logo",image:"https://images.unsplash.com/photo-1634942536790-253d6f7b8a0b?auto=format&fit=crop&w=900&q=80",description:"Brand identity sample"},
  {title:"Campaign Banner",category:"banner",image:"https://images.unsplash.com/photo-1557682250-33bd709cbe85?auto=format&fit=crop&w=900&q=80",description:"Banner design sample"},
  {title:"Custom Jersey",category:"jersey",image:"https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=900&q=80",description:"Sports design sample"},
  {title:"Video Creative",category:"video",image:"https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?auto=format&fit=crop&w=900&q=80",description:"Video editing sample"},
  {title:"Digital Poster",category:"poster",image:"https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=900&q=80",description:"Colorful graphic sample"}
];
let portfolioItems = [];
const portfolioGrid = document.getElementById("portfolioGrid");
const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));

function renderPortfolio(filter = "all") {
  const items = portfolioItems.filter(item => filter === "all" || item.category === filter);
  if (!items.length) {
    portfolioGrid.innerHTML = '<div class="empty-state">এই ক্যাটাগরিতে এখনো কোনো কাজ যোগ করা হয়নি। পরে আবার দেখুন।</div>';
    return;
  }
  portfolioGrid.innerHTML = items.map(item => `
    <article class="portfolio-item">
      <img src="${escapeHTML(item.image)}" alt="${escapeHTML(item.title)}" loading="lazy" onerror="this.style.display='none'">
      <div class="portfolio-meta"><strong>${escapeHTML(item.title)}</strong><span>${escapeHTML(item.description || item.category || "Portfolio work")}</span></div>
    </article>`).join("");
}
async function loadPortfolio() {
  try {
    const response = await fetch("/content/portfolio.json", {cache:"no-store"});
    if (!response.ok) throw new Error("portfolio json unavailable");
    const data = await response.json();
    portfolioItems = Array.isArray(data.items) ? data.items : [];
    if (!portfolioItems.length) portfolioItems = FALLBACK_PORTFOLIO;
  } catch (error) {
    portfolioItems = FALLBACK_PORTFOLIO;
  }
  renderPortfolio();
}
document.getElementById("portfolioFilters").addEventListener("click", event => {
  const button = event.target.closest("[data-filter]");
  if (!button) return;
  document.querySelectorAll(".filter").forEach(el => el.classList.toggle("active", el === button));
  renderPortfolio(button.dataset.filter);
});
document.getElementById("menuToggle").addEventListener("click", () => {
  const nav = document.getElementById("mainNav");
  const isOpen = nav.classList.toggle("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded", String(isOpen));
});
document.querySelectorAll("#mainNav a").forEach(link => link.addEventListener("click", () => {
  document.getElementById("mainNav").classList.remove("open");
  document.getElementById("menuToggle").setAttribute("aria-expanded", "false");
}));
document.querySelectorAll(".order-service").forEach(button => button.addEventListener("click", () => {
  document.getElementById("serviceSelect").value = button.dataset.service;
  document.getElementById("order").scrollIntoView({behavior:"smooth"});
}));
document.getElementById("orderForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = String(form.get("name") || "").trim();
  const service = String(form.get("service") || "").trim();
  const budget = String(form.get("budget") || "").trim();
  const deadline = String(form.get("deadline") || "").trim();
  const details = String(form.get("details") || "").trim();
  if (!name || !service || !details) return;
  const message = [
    "আসসালামু আলাইকুম, Anik Media & Editing।",
    "আমি একটি অর্ডার করতে চাই।",
    `নাম: ${name}`,
    `সার্ভিস: ${service}`,
    budget ? `বাজেট: ${budget}` : "",
    deadline ? `ডেডলাইন: ${deadline}` : "",
    `কাজের বিবরণ: ${details}`
  ].filter(Boolean).join("\n");
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
});
document.getElementById("year").textContent = new Date().getFullYear();
loadPortfolio();
